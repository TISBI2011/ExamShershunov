﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExamShershunov.Pages
{
    /// <summary>
    /// Логика взаимодействия для LiginPage.xaml
    /// </summary>
    public partial class LiginPage : Page
    {
        public LiginPage()
        {
            InitializeComponent();          
        }

        private void BAutorize_Click(object sender, RoutedEventArgs e)
        {
            string login = TBLogin.Text;
            string password = TBPassword.Text;
            string slovo = TBKodSlovo.Text;

            var loggedUser = App.DB.Sotrudniki.FirstOrDefault(x => x.Login == login && x.Password == password && x.KodovoeSlovo == slovo);

            if(loggedUser == null)
            {
                MessageBox.Show("Неправильно Ведены данные");
                return;

            }
            NavigationService.Navigate(new MenedjerPages());
        }
    }
}
